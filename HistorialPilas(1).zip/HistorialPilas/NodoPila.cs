﻿//Clase genrica que representa un noco de una Pila enlazada
//La pila necesita un puntero hacia abajo
public class NodoPila<T>
{
    //Dato almacenado en el nodo (Puede ser cualquier dato)
    public T Dato { get; set; }
    //Referenciar al nodo que esta debajo de esre en la pila
    //En la pila el ultimo nodo en entrar apunta al anterior
    public NodoPila<T> Siguiente { get; set; }
    //Constructor
    public NodoPila(T dato)
    {
        Dato = dato;
        Siguiente = null;

    }
}