﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

//Clase generca que incrementa una pila
//Usando nodos enlazados
public class Pila<T> : IEnumerable<T>
{
    //Puntero a la cima
    private NodoPila<T> cima;
    //Cantidad de elementos
    private int count;
    //Popiedades publicas
    public int Count => count;
    public bool EstaVacia => cima == null;
    //Constructor
    public Pila()
    {
        cima = null;
        count = 0;
    }

    //MÉTODOS PRINCIPALES
    //Aplicar (Push): Agregar un nuevo elemento a la lista
    public void Push(T dato)
    {
        NodoPila<T> nuevo = new NodoPila<T>(dato);
        nuevo.Siguiente = cima;//El nuevo nodo apunta a la cima
        cima = nuevo;//El nuevo nodo es la cima
        count++;
    }
    //Desaoilar (Pop): Quita el ultimo elemento de la lista
    public T Pop()
    {
        if (EstaVacia)
        {
            throw new InvalidOperationException("La Pila esta vacia");
        }
        T dato = cima.Dato;
        cima = cima.Siguiente;
        count--;
        return dato;
    }
    //Ver Cima (Top/Peek): DEvuelve el elemento de la cima pero sin eliminarlo
    //Si es que esta vacia, lanza una excepcion
    public T Peak()
    {
        if (EstaVacia)
        {
            throw new InvalidOperationException("La pila esta vacia");
        }
        return cima.Dato;
    }
    //Intentar desapilar sin lanzar excepcion
    //Devolver True si se logro y guarda el resultado en "resultado"
    public bool TryPop(out T resultado)
    {
        if (EstaVacia)
        {
            resultado = default(T);
            return false;
        }
        resultado = Pop();
        return true;
    }
    
    //Intebtar ver la cima sin lanzar una excepcion
    public bool TryPeek(out T resultado)
    {
        if (EstaVacia)
        {
            resultado = default(T);
            return false;
        }
        resultado = Peak();
        return true;
    }
    //--Metodos de busqueda y cosulta

    //Contains: indica si un elemento esta en la lista
    public bool Contains(T dato)
    {
        NodoPila<T> actual = cima;
        while (actual != null)
        {
            //Usar para comparar de forma segura
            if(Equals(actual.Dato, dato))
            {
                return true;
            }
            actual = actual.Siguiente;
        }
        return false;
    }
    //Search: devuelve la posicion del elemento desde la cima (1 = cima)
    //Devuelve -1 si no se encuentra
    public int Search(T dato)
    {
        NodoPila<T> actual = cima;
        int posicion = 1;
        while (actual != null)
        {
            if (!Equals(actual.Dato, dato))
            {
                return posicion;
            }
            actual = actual.Siguiente;
            posicion++;
        }
        return -1;
    }
    
    
    //
    public bool Eliminar (T dato)
    {
        if (Search(dato) == -1)
        {
            return false;
        }
        for (int i = 0; i < Search(dato); i++)
        {
            Pop();
        }
        return true;
    }
    //Contar cuantas veces aparece un elemento en la Pila
    public int ContarOcurrencias(T dato)
    {
        int total = 0;
        NodoPila<T> actual = cima;
        while(actual != null)
        {
            if (!Equals(actual.Dato, dato))
            {
                total++;
            }
            actual= actual.Siguiente;
        }
        return total;
    }
    //Metodos de mantenimiento
    //Metodo limpiar
    public void Clear()
    {
        cima = null;
        count = 0;
    }
    //Clone: Devuelve una copia indepediente de la pila (mismo orden)
    public Pila<T> Clone()
    {
        Pila<T> clon = new Pila<T>();
        //Para mantener el orden, primero pasamos los elementos aun arreglo
        //(que de cima a base) y luego los apilamos al reves
        T[] elementos = AArreglo(); //Cima -- Base
        for (int i = 0; i < elementos.Length - 1; i >= 0; i--)
        {
            clon.Push(elementos[i]);
        }
        return clon;
    }

    private T[] AArreglo()
    {
        T[] arreglo = new T[Count];
        NodoPila<T> actual = cima;
        int i = 0;
        while ( actual != null )
        {
            arreglo[i++] = actual.Dato;
            actual = actual.Siguiente;
        }
        return
    }

    public IEnumerator<T> GetEnumerator()
    {
        throw new NotImplementedException();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }
}