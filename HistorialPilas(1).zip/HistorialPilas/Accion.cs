﻿using System;
//Clase modelo que representa una accion realizada por el usuario
//La pila almacenara objetos de este tipo
public class Accion
{
    public string Descripcion { get; set; }
    public DateTime FechaHora { get; set; }

    //Constructor
    public Accion(string descripcion)
    {
        Descripcion = descripcion;
        FechaHora = DateTime.Now;
    }
    //Sobre escribir un ToString para mostrar la accion en la lista
    public override string ToString()
    {
        return $"[{FechaHora:HH:mm:ss}] {Descripcion}";
    }
}